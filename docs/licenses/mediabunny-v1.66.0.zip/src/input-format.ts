/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import { Demuxer } from './demuxer';
import { Input } from './input';
import { IsobmffDemuxer } from './isobmff/isobmff-demuxer';
import type { PsshBox } from './isobmff/isobmff-misc';
import {
	EBMLId,
	MAX_HEADER_SIZE,
	MIN_HEADER_SIZE,
	readAsciiString,
	readElementHeader,
	readElementSize,
	readUnsignedInt,
	readVarIntSize,
} from './matroska/ebml';
import { MatroskaDemuxer } from './matroska/matroska-demuxer';
import { Mp3Demuxer } from './mp3/mp3-demuxer';
import { skipId3V2Tags } from './id3';
import { readConfirmedMp3FrameHeader } from './mp3/mp3-reader';
import { OggDemuxer } from './ogg/ogg-demuxer';
import { WaveDemuxer } from './wave/wave-demuxer';
import { readConfirmedAdtsFrameHeader } from './adts/adts-reader';
import { AdtsDemuxer } from './adts/adts-demuxer';
import { readAscii, readBytes, readU32Be, readU64Be } from './reader';
import { FlacDemuxer } from './flac/flac-demuxer';
import { MpegTsDemuxer } from './mpeg-ts/mpeg-ts-demuxer';
import { TS_PACKET_SIZE } from './mpeg-ts/mpeg-ts-misc';
import { HlsDemuxer } from './hls/hls-demuxer';
import { HLS_MIME_TYPE } from './hls/hls-misc';
import { PathedSource } from './source';
import { isThenable, MaybePromise } from './misc';

/**
 * Base class representing an input media file format.
 * @group Input formats
 * @public
 */
export abstract class InputFormat {
	/** @internal */
	abstract _getMatchPosition(input: Input): Promise<number | null>; // Where the format's data starts, if at all

	/** @internal */
	abstract _createDemuxer(input: Input): Demuxer;

	/** Returns the name of the input format. */
	abstract get name(): string;
	/** Returns the typical base MIME type of the input format. */
	abstract get mimeType(): string;
	/**
	 * Whether this input format's tracks store timestamped media data. When `true`, the timestamps of read packets
	 * come from the file, allowing things like gaps in media data or non-zero start times. When `false`, the format's
	 * media data implicitly starts at zero and follows an implicit sequential timing from there, using the intrinsic
	 * durations of the media data.
	 */
	abstract get supportsTimestampedMediaData(): boolean;

	/**
	 * Provided for tree-shakable checking.
	 * @internal
	 */
	_isIsobmff = false;
}

/**
 * Format representing files compatible with the ISO base media file format (ISOBMFF), like MP4 or MOV files.
 *
 * This format can make use of {@link InputOptions.initInput}. When the file contents are fragmented but no track
 * initialization info is provided (no `moov` atom), then it must be provided via `initInput`.
 *
 * @group Input formats
 * @public
 */
export abstract class IsobmffInputFormat extends InputFormat {
	/** @internal */
	protected async _getMajorBrand(input: Input) {
		let slice = input._reader.requestSlice(0, 12);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		const size = readU32Be(slice);
		const fourCc = readAscii(slice, 4);

		if (
			fourCc !== 'ftyp'
			&& fourCc !== 'styp' // Segment
		) {
			return null;
		}

		if (size === 1) {
			// 64-bit size
			let brandSlice = input._reader.requestSlice(16, 4);
			if (isThenable(brandSlice)) brandSlice = await brandSlice;
			if (!brandSlice) {
				return null;
			}

			return readAscii(brandSlice, 4);
		}

		return readAscii(slice, 4);
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new IsobmffDemuxer(input);
	}

	get supportsTimestampedMediaData() {
		return true;
	}

	/** @internal */
	override _isIsobmff = true;
}

/**
 * MPEG-4 Part 14 (MP4) file format.
 *
 * Do not instantiate this class; use the {@link MP4} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class Mp4InputFormat extends IsobmffInputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		const majorBrand = await this._getMajorBrand(input);
		if (majorBrand !== null) {
			return majorBrand !== 'qt  ' ? 0 : null;
		}

		let pos = 0;
		for (let iter = 0; iter < 10; iter++) { // Bounded loop
			let slice = input._reader.requestSlice(pos, 8);
			if (isThenable(slice)) slice = await slice;
			if (!slice) return null;

			let size = readU32Be(slice);
			let headerSize = 8;
			if (size === 1) {
				let sizeExtensionSlice = input._reader.requestSlice(pos + 8, 8);
				if (isThenable(sizeExtensionSlice)) sizeExtensionSlice = await sizeExtensionSlice;
				if (!sizeExtensionSlice) return null;

				size = readU64Be(sizeExtensionSlice);
				headerSize = 16;
			}

			if (size < headerSize) {
				return null; // Hardly a box is it
			}

			const fourCc = readAscii(slice, 4);
			if (
				// Seen in HLS for example, or in normal files without an ftyp box
				fourCc === 'moof'
				|| fourCc === 'sidx'
				|| fourCc === 'moov'
				|| fourCc === 'mdat'
			) {
				return 0;
			} else if (
				fourCc === 'emsg'
				|| fourCc === 'prft'
				|| fourCc === 'free'
				|| fourCc === 'skip'
				|| fourCc === 'wide'
			) {
				// These are boxes that can appear before the first moof in DASH Media Segments, or before the moov or
				// mdat box in files without ftyp box. They're a strong signal that this is indeed ISOBMFF, but just to
				// be sure, let's walk the box structure to make sure it stays sane.
				pos += size;
			} else {
				return null;
			}
		}

		return null;
	}

	get name() {
		return 'MP4';
	}

	get mimeType() {
		return 'video/mp4';
	}
}

/**
 * QuickTime File Format (QTFF), often called MOV.
 *
 * Do not instantiate this class; use the {@link QTFF} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class QuickTimeInputFormat extends IsobmffInputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		const majorBrand = await this._getMajorBrand(input);
		return majorBrand === 'qt  ' ? 0 : null;
	}

	get name() {
		return 'QuickTime File Format';
	}

	get mimeType() {
		return 'video/quicktime';
	}
}

/**
 * Matroska file format.
 *
 * Do not instantiate this class; use the {@link MATROSKA} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class MatroskaInputFormat extends InputFormat {
	/** @internal */
	protected async isSupportedEBMLOfDocType(input: Input, desiredDocType: string) {
		let headerSlice = input._reader.requestSlice(0, MAX_HEADER_SIZE);
		if (isThenable(headerSlice)) headerSlice = await headerSlice;
		if (!headerSlice) return false;

		const varIntSize = readVarIntSize(headerSlice);
		if (varIntSize === null) {
			return false;
		}

		if (varIntSize < 1 || varIntSize > 8) {
			return false;
		}

		const id = readUnsignedInt(headerSlice, varIntSize);
		if (id !== EBMLId.EBML) {
			return false;
		}

		const dataSize = readElementSize(headerSlice);
		if (typeof dataSize !== 'number') {
			return false; // Miss me with that shit
		}

		let dataSlice = input._reader.requestSlice(headerSlice.filePos, dataSize);
		if (isThenable(dataSlice)) dataSlice = await dataSlice;
		if (!dataSlice) return false;

		const startPos = headerSlice.filePos;

		while (dataSlice.filePos <= startPos + dataSize - MIN_HEADER_SIZE) {
			const header = readElementHeader(dataSlice);
			if (!header) break;

			const { id, size } = header;
			const dataStartPos = dataSlice.filePos;
			if (size === undefined) return false;

			if (dataStartPos + size > startPos + dataSize || (size > 8 && id !== EBMLId.DocType)) {
				return false; // The element overruns the header or is an integer of impossible size
			}

			switch (id) {
				case EBMLId.EBMLReadVersion: {
					const ebmlReadVersion = readUnsignedInt(dataSlice, size);
					if (ebmlReadVersion !== 1) {
						return false;
					}
				}; break;
				case EBMLId.DocType: {
					const docType = readAsciiString(dataSlice, size);
					if (docType !== desiredDocType) {
						return false;
					}
				}; break;
				case EBMLId.DocTypeReadVersion: {
					const docTypeReadVersion = readUnsignedInt(dataSlice, size);
					if (docTypeReadVersion > 4) { // Support up to Matroska v4
						return false;
					}
				}; break;
			}

			dataSlice.filePos = dataStartPos + size;
		}

		return true;
	}

	/** @internal */
	async _getMatchPosition(input: Input) {
		return await this.isSupportedEBMLOfDocType(input, 'matroska') ? 0 : null;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new MatroskaDemuxer(input);
	}

	get name() {
		return 'Matroska';
	}

	get mimeType() {
		return 'video/x-matroska';
	}

	get supportsTimestampedMediaData() {
		return true;
	}
}

/**
 * WebM file format, based on Matroska.
 *
 * Do not instantiate this class; use the {@link WEBM} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class WebMInputFormat extends MatroskaInputFormat {
	/** @internal */
	override async _getMatchPosition(input: Input) {
		return await this.isSupportedEBMLOfDocType(input, 'webm') ? 0 : null;
	}

	override get name() {
		return 'WebM';
	}

	override get mimeType() {
		return 'video/webm';
	}
}

/**
 * MP3 file format.
 *
 * Do not instantiate this class; use the {@link MP3} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class Mp3InputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		const startPos = await skipId3V2Tags(input._reader, 0);
		const result = await readConfirmedMp3FrameHeader(input._reader, startPos, 4096, null);
		if (!result) {
			return null;
		}

		// Leading ID3v2 tags are part of the format, junk before the first frame isn't
		return result.startPos === startPos ? 0 : result.startPos;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new Mp3Demuxer(input);
	}

	get name() {
		return 'MP3';
	}

	get mimeType() {
		return 'audio/mpeg';
	}

	get supportsTimestampedMediaData() {
		return false;
	}
}

/**
 * WAVE file format, based on RIFF.
 *
 * Do not instantiate this class; use the {@link WAVE} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class WaveInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		let slice = input._reader.requestSlice(0, 12);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		const riffType = readAscii(slice, 4);
		if (riffType !== 'RIFF' && riffType !== 'RIFX' && riffType !== 'RF64') {
			return null;
		}

		slice.skip(4);

		const format = readAscii(slice, 4);
		return format === 'WAVE' ? 0 : null;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new WaveDemuxer(input);
	}

	get name() {
		return 'WAVE';
	}

	get mimeType() {
		return 'audio/wav';
	}

	get supportsTimestampedMediaData() {
		return false;
	}
}

/**
 * Ogg file format.
 *
 * Do not instantiate this class; use the {@link OGG} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class OggInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		let slice = input._reader.requestSlice(0, 4);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		return readAscii(slice, 4) === 'OggS' ? 0 : null;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new OggDemuxer(input);
	}

	get name() {
		return 'Ogg';
	}

	get mimeType() {
		return 'application/ogg';
	}

	get supportsTimestampedMediaData() {
		return true;
	}
}
/**
 * FLAC file format.
 *
 * Do not instantiate this class; use the {@link FLAC} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class FlacInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		// There might be ID3v2 headers at the start, skip 'em
		const startPos = await skipId3V2Tags(input._reader, 0);

		let slice = input._reader.requestSlice(startPos, 4);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		return readAscii(slice, 4) === 'fLaC' ? 0 : null;
	}

	get name() {
		return 'FLAC';
	}

	get mimeType() {
		return 'audio/flac';
	}

	get supportsTimestampedMediaData() {
		return false;
	}

	/** @internal */
	_createDemuxer(input: Input): Demuxer {
		return new FlacDemuxer(input);
	}
}

/**
 * ADTS file format.
 *
 * Do not instantiate this class; use the {@link ADTS} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class AdtsInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		const startPos = await skipId3V2Tags(input._reader, 0);
		const header = await readConfirmedAdtsFrameHeader(input._reader, startPos, 4096, null);
		if (!header) {
			return null;
		}

		// Leading ID3v2 tags are part of the format, junk before the first frame isn't
		return header.startPos === startPos ? 0 : header.startPos;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new AdtsDemuxer(input);
	}

	get name() {
		return 'ADTS';
	}

	get mimeType() {
		return 'audio/aac';
	}

	get supportsTimestampedMediaData() {
		return false;
	}
}

/**
 * MPEG Transport Stream (MPEG-TS) file format.
 *
 * This format can make use of {@link InputOptions.initInput} to initialize track information even when no
 * initialization information is provided for the track, for example because it has no key frames. In this case, tracks
 * are matched to each other based on their PID.
 *
 * Do not instantiate this class; use the {@link MPEG_TS} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class MpegTsInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		const lengthToCheck = TS_PACKET_SIZE + 16 + 1;
		let slice = input._reader.requestSlice(0, lengthToCheck);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		const bytes = readBytes(slice, lengthToCheck);

		if (bytes[0] === 0x47 && bytes[TS_PACKET_SIZE] === 0x47) {
			// Regular MPEG-TS
			return 0;
		} else if (bytes[0] === 0x47 && bytes[TS_PACKET_SIZE + 16] === 0x47) {
			// MPEG-TS with Forward Error Correction
			return 0;
		} else if (bytes[4] === 0x47 && bytes[4 + TS_PACKET_SIZE + 4] === 0x47) {
			// MPEG-2-TS (DVHS)
			return 0;
		}

		return null;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new MpegTsDemuxer(input);
	}

	get name() {
		return 'MPEG Transport Stream';
	}

	get mimeType() {
		return 'video/MP2T';
	}

	get supportsTimestampedMediaData() {
		return true;
	}
}

/**
 * Media described using the HTTP Live Streaming (HLS) protocol, with playlists in the M3U8 format.
 *
 * Do not instantiate this class; use the {@link HLS} singleton instead.
 *
 * @group Input formats
 * @public
 */
export class HlsInputFormat extends InputFormat {
	/** @internal */
	async _getMatchPosition(input: Input) {
		let slice = input._reader.requestSlice(0, 7);
		if (isThenable(slice)) slice = await slice;
		if (!slice) return null;

		const isM3u8 = readAscii(slice, 7) === '#EXTM3U';
		if (!isM3u8) {
			return null;
		}

		if (!(input._rootSource instanceof PathedSource)) {
			throw new TypeError('HLS inputs require `InputOptions.source` to be a PathedSource or a ref to one.');
		}

		input._rootSource._usedForHls = true;

		return 0;
	}

	/** @internal */
	_createDemuxer(input: Input) {
		return new HlsDemuxer(input);
	}

	get name() {
		return 'HTTP Live Streaming (HLS)';
	}

	get mimeType() {
		return HLS_MIME_TYPE;
	}

	get supportsTimestampedMediaData() {
		return true;
	}
}

/**
 * MP4 input format singleton.
 * @group Input formats
 * @public
 */
export const MP4 = /* #__PURE__ */ new Mp4InputFormat();
/**
 * QuickTime File Format input format singleton.
 * @group Input formats
 * @public
 */
export const QTFF = /* #__PURE__ */ new QuickTimeInputFormat();
/**
 * Matroska input format singleton.
 * @group Input formats
 * @public
 */
export const MATROSKA = /* #__PURE__ */ new MatroskaInputFormat();
/**
 * WebM input format singleton.
 * @group Input formats
 * @public
 */
export const WEBM = /* #__PURE__ */ new WebMInputFormat();
/**
 * MP3 input format singleton.
 * @group Input formats
 * @public
 */
export const MP3 = /* #__PURE__ */ new Mp3InputFormat();
/**
 * WAVE input format singleton.
 * @group Input formats
 * @public
 */
export const WAVE = /* #__PURE__ */ new WaveInputFormat();
/**
 * Ogg input format singleton.
 * @group Input formats
 * @public
 */
export const OGG = /* #__PURE__ */ new OggInputFormat();
/**
 * ADTS input format singleton.
 * @group Input formats
 * @public
 */
export const ADTS = /* #__PURE__ */ new AdtsInputFormat();

/**
 * FLAC input format singleton.
 * @group Input formats
 * @public
 */
export const FLAC = /* #__PURE__ */ new FlacInputFormat();

/**
 * MPEG-TS input format singleton.
 * @group Input formats
 * @public
 */
export const MPEG_TS = /* #__PURE__ */ new MpegTsInputFormat();

/**
 * HLS input format singleton.
 * @group Input formats
 * @public
 */
export const HLS = /* #__PURE__ */ new HlsInputFormat();

/**
 * List of all input format singletons. If you don't need to support all input formats, you should specify the
 * formats individually for better tree shaking.
 * @group Input formats
 * @public
 */
export const ALL_FORMATS: InputFormat[] = [HLS, MP4, QTFF, MATROSKA, WEBM, WAVE, OGG, FLAC, MP3, ADTS, MPEG_TS];

/**
 * List of input formats required for playback of typical HLS manifests. Includes HLS itself as well as the typical
 * segment formats: MPEG Transport Stream (.ts), MP4 (CMAF), ADTS (.aac) and MP3.
 * @group Input formats
 * @public
 */
export const HLS_FORMATS: InputFormat[] = [HLS, MP4, QTFF, MP3, ADTS, MPEG_TS];

/**
 * Additional per-format configuration.
 * @group Input formats
 * @public
 */
export type InputFormatOptions = {
	/** ISOBMFF-specific configuration. */
	isobmff?: IsobmffInputFormatOptions;
	/** HLS-specific configuration. */
	hls?: HlsInputFormatOptions;
};

/**
 * Additional ISOBMFF input configuration.
 * @group Input formats
 * @public
 */
export type IsobmffInputFormatOptions = {
	/**
	 * A callback that gets invoked for each key ID required for sample content decryption. The key ID is provided as a
	 * 32-character lowercase hexadecimal string.
	 *
	 * Must return or resolve to a 32-character hexadecimal string or a 16-byte `Uint8Array`.
	 */
	resolveKeyId?: (options: {
		/** The key ID that is to be resolved to a key. This is a 32-character lowercase hexadecimal string. */
		keyId: string;
		/**
		 * Protection System Specific Header (pssh) boxes that apply to this key ID. Can be used to obtain a
		 * description key from a DRM license server.
		 */
		psshBoxes: PsshBox[];
	}) => MaybePromise<Uint8Array | string>;

	/** @internal */
	_suppressPsshParsing?: boolean;
};

/**
 * Additional HLS input configuration.
 * @group Input formats
 * @public
 */
export type HlsInputFormatOptions = {
	/**
	 * Whether, in the presence of `#EXT-X-PROGRAM-DATE-TIME` tags, to offset track and packet timestamps to be relative
	 * to the Unix epoch.
	 *
	 * Defaults to `true`, meaning packet timestamps map directly to wall-clock time. This guarantees AV sync across
	 * multiple tracks, even with gaps present.
	 *
	 * When you don't want this mapping, you can set this value to `false`. In addition to timestamps not being Unix
	 * timestamps anymore, any gaps in the playlist are also naturally removed. When `false`, you can still access the
	 * wall-clock Unix timestamps via {@link InputTrack.getUnixTimeForTimestamp}.
	 */
	offsetTimestampsByDateTime?: boolean;
};

export const validateInputFormatOptions = (options: InputFormatOptions, prefix: string) => {
	if (!options || typeof options !== 'object') {
		throw new TypeError(`${prefix}, when provided, must be an object.`);
	}
	if (options.isobmff !== undefined) {
		if (!options.isobmff || typeof options.isobmff !== 'object') {
			throw new TypeError(`${prefix}.isobmff, when provided, must be an object.`);
		}
		if (options.isobmff.resolveKeyId !== undefined && typeof options.isobmff.resolveKeyId !== 'function') {
			throw new TypeError(`${prefix}.isobmff.resolveKeyId, when provided, must be a function.`);
		}
	}
	if (options.hls !== undefined) {
		if (!options.hls || typeof options.hls !== 'object') {
			throw new TypeError(`${prefix}.hls, when provided, must be an object.`);
		}
		if (
			options.hls.offsetTimestampsByDateTime !== undefined
			&& typeof options.hls.offsetTimestampsByDateTime !== 'boolean'
		) {
			throw new TypeError(`${prefix}.hls.offsetTimestampsByDateTime, when provided, must be a boolean.`);
		}
	}
};
